package GUI;

import Cell.Grid;

import java.awt.*;

public class Main {
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
//                Game game = new Game();

//                System.out.println("km\u00B2");
//                System.out.println("\u25A0");

//                int[] test = new int[72];
//                for (int i=0; i<test.length; i++)
//                {
//                    System.out.println(test[i]);
//                }



            }
        });
        int[] size = new int[2];
        size[0] = 72;
        size[1] = 72;
        Grid grid = new Grid(size);


    }
}