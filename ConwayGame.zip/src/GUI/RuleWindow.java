package GUI;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;

public class RuleWindow extends JPanel{
    // Components in rule window
    private JLabel ruleTitle = new JLabel("Game Rules");
    private JButton ruleGoBack = new JButton("Go Back");
    private JButton webRule = new JButton("Open Website");
    private JButton ruleStartGame = new JButton("Start Game");

    JLabel ruleDetails = new JLabel("<html>0. This is an adapted version of Conway's <b>Game of Life</b>. The rules below are a brief description of the requirements for the assignment03 for the course <i>Software Construction</i> at University of Zürich. More detailed rules and explanations of the game can be obtained by clicking on the button \"Open Website\".<br><br>\n" +
            "<br>1. This is a two-player only game version. Before the game starts, both players should enter their names separately. Then default cells will be generated automatically on the board.<br><br>" +
            "<br>2. By clicking on one small grid on the board, a cell will be maked to be alive/dead. If the cell is alive, then it stays alive if it has either 2 or 3 live neighbors; If the cell is dead, then it springs to life only in the case that it has 3 live neighbors.<br><br>" +
            "<br>3. Two players take turns following an alphabetical order based on their names. In each round, each player should kill one of the cells of their opponent and activate one of their own cells.<br><br>" +
            "<br>4. At the end of every round, a new generation takes place. With the new generation, if a play is left with no alive cells, he/she loses and the other player wins.</html>");
    public RuleWindow(){
        //JPanel ruleWindow = new JPanel();

        this.setBackground(new Color(146, 172, 209));
        this.setLayout(new FreeLayout());


        ruleTitle.setFont(new Font("Verdana", Font.BOLD, 30));
        ruleTitle.setHorizontalAlignment(SwingConstants.CENTER);
        ruleTitle.setPreferredSize(new Dimension(400, 100));
        this.add(ruleTitle);


        ruleDetails.setFont(new Font("Verdana", Font.PLAIN, 15));
        ruleDetails.setHorizontalAlignment(SwingConstants.LEFT);
        ruleDetails.setPreferredSize(new Dimension(700, 600));
        this.add(ruleDetails);


        webRule.addActionListener((e) -> {
            try {
                Desktop.getDesktop().browse(new URL("http://pi.math.cornell.edu/~lipa/mec/lesson6.html").toURI());
            } catch (IOException | URISyntaxException ex) {
                throw new RuntimeException(ex);
            }
        });
        webRule.setPreferredSize(new Dimension(150, 50));
        this.add(webRule);



        ruleStartGame.setPreferredSize(new Dimension(100, 50));
        this.add(ruleStartGame);


        ruleGoBack.setPreferredSize(new Dimension(100, 50));
        this.add(ruleGoBack);
    }

    public JButton getRuleGoBack() {
        return this.ruleGoBack;
    }

    public JButton getRuleStartGame() {
        return this.ruleStartGame;
    }


    private class FreeLayout extends LayoutAdapter {

        @Override
        public void addLayoutComponent(Component comp, Object constraints) {

        }

        @Override
        public void removeLayoutComponent(Component comp) {

        }

        @Override
        public void layoutContainer(Container parent) {
            int width = parent.getWidth();
            int height = parent.getHeight();


            // Rule window
            ruleTitle.setLocation((width - ruleTitle.getPreferredSize().width) / 2, (height / 15));
            ruleTitle.setSize(ruleTitle.getPreferredSize());

            ruleDetails.setLocation(width / 6, height / 8);
            ruleDetails.setSize(ruleDetails.getPreferredSize());

            webRule.setLocation(width / 5, (int) ((height - webRule.getPreferredSize().height) / 1.1));
            webRule.setSize(webRule.getPreferredSize());

            ruleStartGame.setLocation((int) (width / 2.18), (int) ((height - ruleStartGame.getPreferredSize().height) / 1.1));
            ruleStartGame.setSize(ruleStartGame.getPreferredSize());

            ruleGoBack.setLocation((int) (width / 1.5), (int) ((height - ruleGoBack.getPreferredSize().height) / 1.1));
            ruleGoBack.setSize(ruleGoBack.getPreferredSize());

        }
    }
}
