package GUI;

import java.awt.*;

public class FreeLayout extends LayoutAdapter {

    @Override
    public void addLayoutComponent(Component comp, Object constraints) {

    }

    @Override
    public void removeLayoutComponent(Component comp) {

    }

    @Override
    public void layoutContainer(Container parent) {
        int width = parent.getWidth();
        int height = parent.getHeight();

        // Main window
//        contentTitle.setLocation((width - contentTitle.getPreferredSize().width) / 2, (height - contentTitle.getPreferredSize().height) / 5);
//        contentTitle.setSize(contentTitle.getPreferredSize());
//
//        startGame.setLocation((width - startGame.getPreferredSize().width) / 2, (int) ((height - startGame.getPreferredSize().height) / 1.5));
//        startGame.setSize(startGame.getPreferredSize());
//
//        readRule.setLocation((width - readRule.getPreferredSize().width) / 2, (int) ((height - readRule.getPreferredSize().height) / 1.28571429));
//        readRule.setSize(readRule.getPreferredSize());
//
//        exitGame.setLocation((width - exitGame.getPreferredSize().width) / 2, (int) ((height - exitGame.getPreferredSize().height) / 1.125));
//        exitGame.setSize(exitGame.getPreferredSize());
//
//        // Game window left
//        left.setLocation(0, 0);
////            left.setLocation(width, height);
//        left.setSize(left.getPreferredSize());
//
//        cellBoard.setLocation(15, 40);
//        cellBoard.setSize(cellBoard.getPreferredSize());
//
//        init.setLocation(width / 5, (int) (height/ 1.1875));
//        init.setSize(init.getPreferredSize());
//
//        next.setLocation((int) (width * 2.2), (int) (height/ 1.1875));
//        next.setSize(next.getPreferredSize());
//
//        // Game window right
//        right.setLocation(width - (width - (left.getPreferredSize().width)), 0);
//        right.setSize(right.getPreferredSize());
//
//        player1.setLocation(width / 5, 100);
//        player1.setSize(player1.getPreferredSize());
//
//        currentCells1.setLocation((int) (width / 5), 130);
//        currentCells1.setSize(currentCells1.getPreferredSize());
//
//        player2.setLocation(width / 5, 300);
//        player2.setSize(player2.getPreferredSize());
//
//        currentCells2.setLocation(width / 5, 330);
//        currentCells2.setSize(currentCells2.getPreferredSize());
//
//        currentGeneration.setLocation(width / 5, 500);
//        currentGeneration.setSize(currentGeneration.getPreferredSize());
//
//        restartButton.setLocation(width / 5, (int) (height/ 1.35));
//        restartButton.setSize(restartButton.getPreferredSize());
//
//        gameGoBack.setLocation(width / 5, (int) (height/ 1.1875));
//        gameGoBack.setSize(gameGoBack.getPreferredSize());
//
//
//        // Rule window
//        ruleTitle.setLocation((width - ruleTitle.getPreferredSize().width) / 2, (height / 15));
//        ruleTitle.setSize(ruleTitle.getPreferredSize());
//
//        ruleDetails.setLocation(width / 6, height / 8);
//        ruleDetails.setSize(ruleDetails.getPreferredSize());
//
//        webRule.setLocation(width / 5, (int) ((height - webRule.getPreferredSize().height) / 1.1));
//        webRule.setSize(webRule.getPreferredSize());
//
//        ruleStartGame.setLocation((int) (width / 2.18), (int) ((height - ruleStartGame.getPreferredSize().height) / 1.1));
//        ruleStartGame.setSize(ruleStartGame.getPreferredSize());
//
//        ruleGoBack.setLocation((int) (width / 1.5), (int) ((height - ruleGoBack.getPreferredSize().height) / 1.1));
//        ruleGoBack.setSize(ruleGoBack.getPreferredSize());

    }
}
