package GUI;

import javax.swing.*;
import java.awt.*;

public class Game extends JFrame {
    private MainWindow mainWindow = new MainWindow();
    private GameWindow gameWindow = new GameWindow();
    private RuleWindow ruleWindow = new RuleWindow();

    public Game() {
        this.setTitle("Software Constrution HS22 - Group 33 @ UZH");
        this.setSize(1000, 950);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);

        this.setContentPane(mainWindow);


        mainWindow.getStartGame().addActionListener((e) -> {
            setContentPane(gameWindow);
            revalidate();
            gameWindow.restart();
        });

        mainWindow.getReadRule().addActionListener((e) -> {
            setContentPane(ruleWindow);
            revalidate();
        });

        ///////////////////////////////
        gameWindow.getGameGoBack().addActionListener((e) -> {
            int option = JOptionPane.showConfirmDialog(null, "Do you want to go back to the last page? This game cannot be retrievable.", "Confirmation", JOptionPane.YES_NO_OPTION);
            if (option == 0) {
                setContentPane(mainWindow);
                revalidate();
            } else {
            }

        });

        ///////////////////////////////
        ruleWindow.getRuleGoBack().addActionListener((e) -> {
            setContentPane(gameWindow);
            revalidate();
            gameWindow.restart();
        });

        ruleWindow.getRuleStartGame().addActionListener((e) -> {
            setContentPane(gameWindow);
            revalidate();
        });
    }









        public static void main(String[] args) {
            EventQueue.invokeLater(new Runnable() {
                @Override
                public void run() {
                    Game game = new Game();

                }
            });
        }

    }
