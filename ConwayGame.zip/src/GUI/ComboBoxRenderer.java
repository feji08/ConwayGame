package GUI;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;


class ComboBoxRenderer extends DefaultListCellRenderer {
    private ArrayList<Color> colors = new ArrayList<>();

    public ComboBoxRenderer(){
        colors.add(new Color(215,157,164));
        colors.add(new Color(227,140,122));
        colors.add(new Color(227,194,161));
        colors.add(new Color(207,215,176));
        colors.add(new Color(153,164,188));
    }


    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
    {
        JLabel lbl = (JLabel)super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        if(index > -1) lbl.setForeground(colors.get(index));
        return lbl;

    }

    public ArrayList<Color> getColors() {
        return this.colors;
    }


}