package GUI;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import java.awt.*;

public class CellBoard extends JPanel {

    private int row = 72;
    private int col = 72;

    private JPanel[][] board = new JPanel[row][col];
    Border boarder = BorderFactory.createEtchedBorder(EtchedBorder.RAISED);
    public CellBoard() {
        Dimension dims = new Dimension(10, 10);
        setLayout(new GridLayout(row, col));
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                JPanel b = new JPanel();
                b.setPreferredSize(dims);
                b.setMinimumSize(dims);
                b.setBackground(Color.WHITE);
                b.setBorder(boarder);
                this.add(b);
                board[i][j] = b;
            }
        }
    }

    public JPanel[][] getBoard() {
        return this.board;
    }

    public int getRow() {
        return this.row;
    }

    public int getCol() {
        return this.col;
    }

}