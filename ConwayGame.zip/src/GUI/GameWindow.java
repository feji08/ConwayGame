package GUI;

import Cell.Cell;
import Cell.Grid;
import Player.Player;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class GameWindow extends JPanel {
    private CellBoard cellBoard = new CellBoard();
    // Components in game window
    private JPanel left = new JPanel();
    private JButton init = new JButton("Initialisation");
    private JButton next = new JButton("Next Generation");
    private JPanel right = new JPanel();
    private JLabel currentInfo = new JLabel();
    private JLabel firstPlayer = new JLabel();
    private JLabel currentCells1 = new JLabel();
    private JLabel secondPlayer = new JLabel();
    private JLabel currentCells2 = new JLabel();
    private JLabel currentGeneration = new JLabel();
    private JButton restartButton = new JButton("Restart");
    private JButton gameGoBack = new JButton("Go Back");
    private JComboBox chooseColor;
    private ComboBoxRenderer comboBoxRenderer;

    ////////////////////////
    private Player[] players;
    private Grid grid;
    private boolean isInitialised;
    private int generation;
    private boolean isFirstPlayer;
    private boolean toKill;
    private boolean gameOver;
    private boolean isUpdated;

    public GameWindow() {
        this.setLayout(new FreeLayout());

        /////// left side

        left.setLayout(new FreeLayout());
        left.setBackground(new Color(250, 234, 211));
        left.setPreferredSize(new Dimension(750, 950));
        left.setOpaque(true);


        init.setPreferredSize(new Dimension(150, 50));
        init.addActionListener((e) -> {
            playerInit();
            gameProcess();
        });

        currentInfo.setPreferredSize(new Dimension(800, 30));


//        if(!gameOver){
//            next.setEnabled(true);
//
//        }
//        else{
//            if (players[0].getCellNum() == 0){
//                currentInfo.setText("<html>Game over! <br>" + players[1].getName() + "</html>");
//                JOptionPane.showConfirmDialog(null, "Game over! " + players[1].getName() + "has won!", "Game Over", JOptionPane.DEFAULT_OPTION);
//                this.gameOver = true;
//                next.setEnabled(false);
//            }
//            else if(players[1].getCellNum() == 0){
//                currentInfo.setText("<html>Game over! <br>" + players[0].getName() + "</html>");
//                JOptionPane.showConfirmDialog(null, "Game over! " + players[0].getName() + "has won!", "Game Over", JOptionPane.DEFAULT_OPTION);
//                this.gameOver = true;
//            next.setEnabled(false);}
//        }

        next.setPreferredSize(new Dimension(150, 50));
        next.addActionListener((e) -> {
            updateGernation();
        });



        left.add(cellBoard);
        left.add(init);
        left.add(currentInfo);
        left.add(next);


        /////// right side

        right.setLayout(new FreeLayout());
        right.setBackground(new Color(253, 249, 238));
        right.setPreferredSize(new Dimension(250, 950));
        right.setOpaque(true);

        firstPlayer.setPreferredSize(new Dimension(100, 20));
        currentCells1.setPreferredSize(new Dimension(100, 20));
        secondPlayer.setPreferredSize(new Dimension(100, 20));
        currentCells2.setPreferredSize(new Dimension(100, 20));
        currentGeneration.setPreferredSize(new Dimension(200, 20));


        restartButton.addActionListener((e) -> {
            restart();
        });
        restartButton.setPreferredSize(new Dimension(100, 50));
        gameGoBack.setPreferredSize(new Dimension(100, 50));

        right.add(firstPlayer);
        right.add(currentCells1);
        right.add(secondPlayer);
        right.add(currentCells2);
        right.add(currentGeneration);
        right.add(restartButton);
        right.add(gameGoBack);

        this.add(left);
        this.add(right);

        gameInit();
    }

    private void updateGernation() {
        this.generation += 1;
        currentGeneration.setText("<html>Current Generations: <i>" + this.generation + "</i></html>");
        this.grid.generate();
        gridToBoard();
        updateCellNum();
        this.isUpdated = true;
    }

    private void gameProcess() {
        if (isInitialised == true) {
                this.cellBoard.addMouseListener(enableClick);
            }
    }

    MouseListener enableClick = new MouseAdapter() {
        JPanel[][] board = cellBoard.getBoard();
        public void mouseClicked(MouseEvent e) {
            int c = (e.getX() / 10);
            int r = (e.getY() / 10);
                if (isFirstPlayer) {
                    if (toKill) {
                        currentInfo.setText("<html>This is" + players[0].getName() + "'s turn. <br>Please choose an enemy cell to kill.</html>");
                        if (board[r][c].getBackground() == Color.WHITE) {
                            currentInfo.setText("<html>This is " + players[0].getName() + "'s turn. <br>This cell is not alive.</html>");
                        } else if (board[r][c].getBackground() == players[0].getColor()) {
                            currentInfo.setText("<html>This is " + players[0].getName() + "'s turn. <br>This is your cell, please choose an enemy cell to kill.</html>");
                        } else {
                            currentInfo.setText("<html>This is " + players[0].getName() + "'s turn. <br>You killed an enemy cell. Now, please choose a dead cell to activate.</html>");
                            board[r][c].setBackground(Color.WHITE);
                            grid.killCell(r, c);
                            toKill = false;
                        }
                    } else {
                        if (board[r][c].getBackground() == Color.WHITE) {
                            board[r][c].setBackground(players[0].getColor());
                            grid.activateCell(players[0].getCamp(), r, c);
                            currentInfo.setText("<html>This is " + players[0].getName() + "'s turn. <br>You have activated a cell</html>.");
                        } else {
                            currentInfo.setText("<html>This is" + players[0].getName() + "'s turn. <br>There is already a cell.</html>");
                        }
                        isFirstPlayer = false;
                        toKill = true;
                        currentInfo.setText("<html>This is " + players[1].getName() + "'s turn. <br>Please choose an enemy cell to kill.</html>");
                        isUpdated = false;
                    }
                } else {
                    if (toKill) {
                        if (board[r][c].getBackground() == Color.WHITE) {
                            currentInfo.setText("<html>This is " + players[1].getName() + "'s turn. <br>This cell is not alive.");
                        } else if (board[r][c].getBackground() == players[1].getColor()) {
                            currentInfo.setText("<html>This is " + players[1].getName() + "'s turn. <br>This is your cell, please choose an enemy cell to kill.");
                        } else {
                            currentInfo.setText("<html>This is " + players[1].getName() + "'s turn. <br>You killed an enemy cell. Now, please choose a dead cell to activate.");
                            board[r][c].setBackground(Color.WHITE);
                            grid.killCell(r, c);
                            toKill = false;
                        }
                    } else {
                        currentInfo.setText("<html>This is " + players[1].getName() + "'s turn. <br>Please choose a dead cell to activate.");
                        if (board[r][c].getBackground() == Color.WHITE) {
                            board[r][c].setBackground(players[1].getColor());
                            grid.activateCell(players[1].getCamp(), r, c);
                            currentInfo.setText("<html>This is " + players[1].getName() + "'s turn. <br>You have activated a cell.");
                        } else {
                            currentInfo.setText("<html>This is " + players[1].getName() + "'s turn. <br>There is already a cell.");
                        }
                        isFirstPlayer = true;
                        toKill = true;
                        currentInfo.setText("<html>This is " + players[0].getName() + "'s turn. <br>Please choose an enemy cell to kill.</html>");
                        isUpdated = false;
                    }
                }

        }
    };

//    private void gameProcess(){
//        JPanel[][] board = this.cellBoard.getBoard();
//        this.cellBoard.addMouseListener(new MouseAdapter() {
//            @Override
//            public void mouseClicked(MouseEvent e) {
//                if (isInitialised == true){
//                    isGameOver();
//                    if (gameOver == false){
//                        int c = (e.getX() / 10);
//                        int r = (e.getY() / 10);
//                        if(isFirstPlayer) {
//                            if (toKill) {
//                                currentInfo.setText("<html>This is" + players[0].getName() + "'s turn. <br>Please choose an enemy cell to kill.</html>");
//                                if (board[r][c].getBackground() == Color.WHITE) {
//                                    currentInfo.setText("<html>This is " + players[0].getName() + "'s turn. <br>This cell is not alive.</html>");
//                                } else if (board[r][c].getBackground() == players[0].getColor()) {
//                                    currentInfo.setText("<html>This is " + players[0].getName() + "'s turn. <br>This is your cell, please choose an enemy cell to kill.</html>");
//                                } else {
//                                    currentInfo.setText("<html>This is " + players[0].getName() + "'s turn. <br>You killed an enemy cell. Now, please choose a dead cell to activate.</html>");
//                                    board[r][c].setBackground(Color.WHITE);
//                                    grid.killCell(r, c);
//                                    toKill = false;
//                                }
//                            } else {
//                                if (board[r][c].getBackground() == Color.WHITE) {
//                                    board[r][c].setBackground(players[0].getColor());
//                                    grid.activateCell(players[0].getCamp(), r, c);
//                                    currentInfo.setText("<html>This is " + players[0].getName() + "'s turn. <br>You have activated a cell</html>.");
//                                } else {
//                                    currentInfo.setText("<html>This is" + players[0].getName() + "'s turn. <br>There is already a cell.</html>");
//                                }
//                                isFirstPlayer = false;
//                                toKill = true;
//                                currentInfo.setText("<html>This is " + players[1].getName() + "'s turn. <br>Please choose an enemy cell to kill.</html>");
//                            }
//                        }
//                        else{
//                            updateCellNum(players[1], currentCells2);
//                            if (toKill) {
//                                if (board[r][c].getBackground() == Color.WHITE) {
//                                    currentInfo.setText("<html>This is " + players[1].getName() + "'s turn. <br>This cell is not alive.");
//                                } else if (board[r][c].getBackground() == players[1].getColor()) {
//                                    currentInfo.setText("<html>This is " + players[1].getName() + "'s turn. <br>This is your cell, please choose an enemy cell to kill.");
//                                } else {
//                                    currentInfo.setText("<html>This is " + players[1].getName() + "'s turn. <br>You killed an enemy cell. Now, please choose a dead cell to activate.");
//                                    board[r][c].setBackground(Color.WHITE);
//                                    grid.killCell(r, c);
//                                    toKill = false;
//                                }
//                            }
//                            else {
//                                currentInfo.setText("<html>This is " + players[1].getName() + "'s turn. <br>Please choose a dead cell to activate.");
//                                if (board[r][c].getBackground() == Color.WHITE) {
//                                    board[r][c].setBackground(players[1].getColor());
//                                    grid.activateCell(players[1].getCamp(), r, c);
//                                    currentInfo.setText("<html>This is " + players[1].getName() + "'s turn. <br>You have activated a cell.");
//                                } else {
//                                    currentInfo.setText("<html>This is " + players[1].getName() + "'s turn. <br>There is already a cell.");
//                                }
//                                isFirstPlayer = true;
//                                toKill = true;
//                                currentInfo.setText("<html>This is " + players[0].getName() + "'s turn. <br>Please choose an enemy cell to kill.</html>");
//                            }
//                        }
//                    }
//            }
//        }
//    });
//    }



    private void defaultBoard(){
        String camp1 = this.players[0].getCamp();
        String camp2 = this.players[1].getCamp();
        grid.activateCell(camp1,2,2);
        grid.activateCell(camp1,2,3);
        grid.activateCell(camp1,2,4);
        grid.activateCell(camp1,3,2);
        grid.activateCell(camp2,3,3);
        grid.activateCell(camp1,3,4);
        grid.activateCell(camp1,4,2);
        grid.activateCell(camp1,4,3);
        grid.activateCell(camp1,4,4);

        grid.activateCell(camp2,7,7);
        grid.activateCell(camp2,7,8);
        grid.activateCell(camp2,7,9);
        grid.activateCell(camp2,8,7);
        grid.activateCell(camp1,8,8);
        grid.activateCell(camp2,8,9);
        grid.activateCell(camp2,9,7);
        grid.activateCell(camp2,9,8);
        grid.activateCell(camp2,9,9);

    }

    private void gridToBoard(){
        Cell[][] cells = this.grid.getCells();
        JPanel[][] board = this.cellBoard.getBoard();
        for (int i = 0; i < this.grid.getRowSize(); i++) {
            for (int j = 0; j < this.grid.getColumnSize(); j++) {
                if (cells[i][j].isAlive()) {
                    if (cells[i][j].getCamp() == this.players[0].getCamp()){
                    board[i][j].setBackground(this.players[0].getColor());
                    }
                    else {
                        board[i][j].setBackground(this.players[1].getColor());
                    }

                }
                else{
                    board[i][j].setBackground(Color.WHITE);
                }
            }
        }
    }

    private void gameInit(){
        this.players = new Player[2];
        int[] size = new int[2];
        size[0] = cellBoard.getRow();
        size[1] = cellBoard.getCol();
        this.grid = new Grid(size);

        this.isInitialised = false;
        this.generation = 0;
        this.isFirstPlayer = true;
        this.toKill = true;
        this.gameOver = false;
        this.isUpdated = false;

        currentInfo.setText("First of all, please click on the 'Initialisation' button to initialise the game, otherwise you will not be able to click on the board.");
        firstPlayer.setForeground(Color.BLACK);
        firstPlayer.setText("<html>Player 1: <i>null</i></html>");
        currentCells1.setText("<html>Current Cells: <i>0</i></html>");
        secondPlayer.setForeground(Color.BLACK);
        secondPlayer.setText("<html>Player 2: <i>null</i></html>");
        currentCells2.setText("<html>Current Cells: <i>0</i></html>");
        currentGeneration.setText("<html>Current Generations: <i>0</i></html>");

        resetColor();
    }
    private void chooseColorinit(){
        JComboBox box = new JComboBox();
        ComboBoxRenderer renderer = new ComboBoxRenderer();
        box.setBackground(new Color(253, 249, 238));
        box.setRenderer(renderer);
        box.addItem("Red");
        box.addItem("Orange");
        box.addItem("Yellow");
        box.addItem("Green");
        box.addItem("Blue");

        this.chooseColor = box;
        this.comboBoxRenderer = renderer;
    }
    private void playerInit(){
        chooseColorinit();

        String firstName = JOptionPane.showInputDialog(null,"Please enter your name: ","Initialisation for the first player", JOptionPane.QUESTION_MESSAGE);
        if (firstName.isEmpty()) {
            firstName = "Player1";
        }
        else {
        }
        Player player1 = new Player(this.grid, firstName,"camp1");
        int option1 = JOptionPane.showConfirmDialog(null, this.chooseColor, firstName + ", please choose your color", JOptionPane.DEFAULT_OPTION);
        if (option1 == 0) {
            int firstSelection = this.chooseColor.getSelectedIndex();
            player1.setColor(this.comboBoxRenderer.getColors().get(firstSelection));
            this.chooseColor.removeItemAt(firstSelection);
            this.comboBoxRenderer.getColors().remove(firstSelection);
        }
        else {
        }

        String secondName = JOptionPane.showInputDialog(null,"Please enter your name: ","Initialisation for the second player", JOptionPane.QUESTION_MESSAGE);
        if (secondName.isEmpty()) {
            secondName = "Player2";
        }
        else {
        }
        Player player2 = new Player(this.grid, secondName,"camp2");
        int option2 = JOptionPane.showConfirmDialog(null, this.chooseColor, secondName + ", please choose your color", JOptionPane.DEFAULT_OPTION);
        if (option2 == 0) {
            int secondSelection = this.chooseColor.getSelectedIndex();
            player2.setColor(this.comboBoxRenderer.getColors().get(secondSelection));
        }
        else {
        }

        if(player1.getName().compareToIgnoreCase(player2.getName()) < 0 ){
            this.players[0] = player1;
            this.players[1] = player2;
        }else{
            this.players[0] = player2;
            this.players[1] = player1;
        }

        setName();
        defaultBoard();
        gridToBoard();
        updateCellNum();

        this.isInitialised = true;
        currentInfo.setText("<html>This is " + players[0].getName() + "'s turn. <br>Please choose an enemy cell to kill.</html>");
    }

    private void updateCellNum(){
        int cell1 = players[0].getCellNum();
        int cell2 = players[1].getCellNum();
        currentCells1.setText("Current Cells: " + cell1);
        currentCells2.setText("Current Cells: " + cell2);
    }



    private void setName(){
        firstPlayer.setText("Player 1: " + this.players[0].getName());
        firstPlayer.setForeground(this.players[0].getColor());
        secondPlayer.setText("<html><b>Player 2: " + this.players[1].getName());
        secondPlayer.setForeground(this.players[1].getColor());
    }

    private void resetColor(){
        JPanel[][] board = cellBoard.getBoard();
        for (int i = 0; i < cellBoard.getRow(); i++) {
            for (int j = 0; j < cellBoard.getCol(); j++) {
                Color bgcolor = board[i][j].getBackground();
                if (bgcolor != Color.WHITE){
                    board[i][j].setBackground(Color.WHITE);
                }
            }
        }
    }

    public void restart(){
        gameInit();
    }




    public JButton getGameGoBack() {
        return this.gameGoBack;
    }

    private class FreeLayout extends LayoutAdapter {

        @Override
        public void addLayoutComponent(Component comp, Object constraints) {

        }

        @Override
        public void removeLayoutComponent(Component comp) {

        }

        @Override
        public void layoutContainer(Container parent) {
            int width = parent.getWidth();
            int height = parent.getHeight();


            // Game window left
            left.setLocation(0, 0);
            left.setSize(left.getPreferredSize());

            cellBoard.setLocation(15, 40);
            cellBoard.setSize(cellBoard.getPreferredSize());

            init.setLocation(width / 5, (int) (height/ 1.1875));
            init.setSize(init.getPreferredSize());

            currentInfo.setLocation(width / 14, 5);
            currentInfo.setSize(currentInfo.getPreferredSize());

            next.setLocation((int) (width * 2.2), (int) (height/ 1.1875));
            next.setSize(next.getPreferredSize());

            // Game window right
            right.setLocation(width - (width - (left.getPreferredSize().width)), 0);
            right.setSize(right.getPreferredSize());

            firstPlayer.setLocation(width / 5, 100);
            firstPlayer.setSize(firstPlayer.getPreferredSize());

            currentCells1.setLocation((int) (width / 5), 130);
            currentCells1.setSize(currentCells1.getPreferredSize());

            secondPlayer.setLocation(width / 5, 300);
            secondPlayer.setSize(secondPlayer.getPreferredSize());

            currentCells2.setLocation(width / 5, 330);
            currentCells2.setSize(currentCells2.getPreferredSize());

            currentGeneration.setLocation(width / 5, 500);
            currentGeneration.setSize(currentGeneration.getPreferredSize());

            restartButton.setLocation(width / 5, (int) (height/ 1.35));
            restartButton.setSize(restartButton.getPreferredSize());

            gameGoBack.setLocation(width / 5, (int) (height/ 1.1875));
            gameGoBack.setSize(gameGoBack.getPreferredSize());

        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                Game game = new Game();

            }
        });
    }
}
