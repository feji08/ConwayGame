package GUI;

import javax.swing.*;
import java.awt.*;

public class MainWindow extends JPanel {
    // Components in main window
    private JLabel contentTitle = new JLabel("Conway’s Game of Life: Two-Player Version");
    private JButton startGame = new JButton("Start Game");
    private JButton readRule = new JButton("Read Rules");
    private JButton exitGame = new JButton("Exit Game");
//    private FreeLayout freeLayout = new FreeLayout();

    public MainWindow() {
        this.setLayout(new FreeLayout());
//        this.setLayout(freeLayout);
        this.setBackground(new Color(201, 218, 191));
        contentTitle.setFont(new Font("Verdana", Font.BOLD, 25));
        contentTitle.setHorizontalAlignment(SwingConstants.CENTER);
        contentTitle.setPreferredSize(new Dimension(700, 200));


        startGame.setPreferredSize(new Dimension(100, 50));
        readRule.setPreferredSize(new Dimension(100, 50));


        exitGame.addActionListener((e) -> {
            System.exit(0);
        });
        exitGame.setPreferredSize(new Dimension(100, 50));

        this.add(contentTitle);
        this.add(startGame);
        this.add(readRule);
        this.add(exitGame);
    }


    public JButton getStartGame() {
        return this.startGame;
    }

    public JButton getReadRule() {
        return this.readRule;
    }




    private class FreeLayout extends LayoutAdapter {

        @Override
        public void addLayoutComponent(Component comp, Object constraints) {

        }

        @Override
        public void removeLayoutComponent(Component comp) {

        }

        @Override
        public void layoutContainer(Container parent) {
            int width = parent.getWidth();
            int height = parent.getHeight();

            // Main window
            contentTitle.setLocation((width - contentTitle.getPreferredSize().width) / 2, (height - contentTitle.getPreferredSize().height) / 5);
            contentTitle.setSize(contentTitle.getPreferredSize());

            startGame.setLocation((width - startGame.getPreferredSize().width) / 2, (int) ((height - startGame.getPreferredSize().height) / 1.5));
            startGame.setSize(startGame.getPreferredSize());

            readRule.setLocation((width - readRule.getPreferredSize().width) / 2, (int) ((height - readRule.getPreferredSize().height) / 1.28571429));
            readRule.setSize(readRule.getPreferredSize());

            exitGame.setLocation((width - exitGame.getPreferredSize().width) / 2, (int) ((height - exitGame.getPreferredSize().height) / 1.125));
            exitGame.setSize(exitGame.getPreferredSize());
        }
    }
}
