public class BoardConfigurationStrategy {
    public void BoardConfiguration(int pattern){
        if(pattern == 1){

        }
        if(pattern == 2){

        }
        if(pattern == 3){

        }
        if(pattern == 4){

        }
        if(pattern == 5){

        }
    }
}
